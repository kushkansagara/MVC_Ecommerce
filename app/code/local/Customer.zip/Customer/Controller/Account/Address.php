<?php
class Customer_Controller_Account_Address extends Core_Controller_Front_Action
{

}
?>