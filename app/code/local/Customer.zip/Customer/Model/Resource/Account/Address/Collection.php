<?php
class Customer_Model_Resource_Account_Address_Collection extends core_Model_Resource_Collection_Abstract
{

}
?>