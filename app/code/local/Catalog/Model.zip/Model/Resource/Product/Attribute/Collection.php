<?php

class Catalog_Model_Resource_Product_Attribute_Collection extends core_Model_Resource_Collection_Abstract
{

}
?>