<?php

class Catalog_Model_Resource_Category_Collection extends core_Model_Resource_Collection_Abstract
{

}
?>